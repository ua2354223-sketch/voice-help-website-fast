"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Loader2, Download, Mic, Volume2, Languages, Wand2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface Voice {
  voice_id: string
  name: string
  labels: {
    accent?: string
    language?: string
    use_case?: string
  }
}

const VOICE_STYLE_PROMPT = `Create a calm, deep, and authoritative male voice.
The voice should sound human, mature, and confident, not robotic or overly dramatic.

Speaking style:
- Slow and controlled pace (around 0.85x speed)
- Natural pauses after important sentences
- Clear pronunciation with neutral American/British accent
- Serious, thoughtful, and reflective tone
- Emotion should be subtle, calm, and meaningful

Voice personality:
- Sounds like a wise mentor or disciplined leader
- Inspires trust, focus, and responsibility
- No shouting, no excitement, no preaching tone

Technical requirements:
- Slightly deep pitch
- Warm but firm delivery
- Balanced clarity (not sharp, not flat)

Purpose: Motivational and self-discipline YouTube automation videos for mature audience.`

export default function VoiceCloning() {
  const [text, setText] = useState("")
  const [selectedVoice, setSelectedVoice] = useState("JBFqnCBsd6RMkjVDRZzb")
  const [stability, setStability] = useState([0.5])
  const [similarity, setSimilarity] = useState([0.8])
  const [isGenerating, setIsGenerating] = useState(false)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [voices, setVoices] = useState<Voice[]>([])
  const [isLoadingVoices, setIsLoadingVoices] = useState(false)
  const [activeTab, setActiveTab] = useState("tts")
  const audioRef = useRef<HTMLAudioElement>(null)
  const { toast } = useToast()

  // Load available voices
  const loadVoices = async () => {
    setIsLoadingVoices(true)
    try {
      const response = await fetch("https://elevenlabs-proxy-server-lipn.onrender.com/v1/voices", {
        method: "GET",
        headers: {
          customerId: "null",
          "Content-Type": "application/json",
          Authorization: "Bearer xxx",
        },
      })

      if (!response.ok) {
        throw new Error("Failed to load voices")
      }

      const data = await response.json()
      setVoices(data.voices || [])

      toast({
        title: "Voices Loaded Successfully",
        description: `${data.voices?.length || 0} voices available`,
      })
    } catch (error) {
      toast({
        title: "Error Loading Voices",
        description: "Using default voice",
        variant: "destructive",
      })
    } finally {
      setIsLoadingVoices(false)
    }
  }

  // Generate Text-to-Speech
  const generateSpeech = async () => {
    if (!text.trim()) {
      toast({
        title: "Text Required",
        description: "Please enter text to convert to speech",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setAudioUrl(null)

    try {
      const response = await fetch(
        `https://elevenlabs-proxy-server-lipn.onrender.com/v1/text-to-speech/${selectedVoice}`,
        {
          method: "POST",
          headers: {
            customerId: "null",
            "Content-Type": "application/json",
            Authorization: "Bearer xxx",
            Accept: "audio/mpeg",
          },
          body: JSON.stringify({
            text: text,
            model_id: "eleven_multilingual_v2",
            voice_settings: {
              stability: stability[0],
              similarity_boost: similarity[0],
              style: 0.5,
              use_speaker_boost: true,
            },
          }),
        },
      )

      if (!response.ok) {
        throw new Error("Failed to generate speech")
      }

      const audioBlob = await response.blob()
      const url = URL.createObjectURL(audioBlob)
      setAudioUrl(url)

      toast({
        title: "Success!",
        description: "Voice generated successfully. Click play to listen.",
      })
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  // Download audio
  const downloadAudio = () => {
    if (!audioUrl) return

    const link = document.createElement("a")
    link.href = audioUrl
    link.download = `voiceover-${Date.now()}.mp3`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "Download Started",
      description: "Your audio file is downloading",
    })
  }

  // Clone voice (upload samples)
  const [cloneFiles, setCloneFiles] = useState<FileList | null>(null)
  const [cloneName, setCloneName] = useState("")
  const [isCloning, setIsCloning] = useState(false)

  const cloneVoice = async () => {
    if (!cloneFiles || cloneFiles.length === 0) {
      toast({
        title: "Audio Files Required",
        description: "Please upload at least one audio sample",
        variant: "destructive",
      })
      return
    }

    if (!cloneName.trim()) {
      toast({
        title: "Voice Name Required",
        description: "Please enter a name for your cloned voice",
        variant: "destructive",
      })
      return
    }

    setIsCloning(true)

    try {
      const formData = new FormData()
      formData.append("name", cloneName)
      formData.append("description", "Cloned voice for YouTube content creation")

      // Add audio files
      for (let i = 0; i < cloneFiles.length; i++) {
        formData.append("files", cloneFiles[i])
      }

      const response = await fetch("https://elevenlabs-proxy-server-lipn.onrender.com/v1/voices/add", {
        method: "POST",
        headers: {
          customerId: "null",
          Authorization: "Bearer xxx",
        },
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Failed to clone voice")
      }

      const data = await response.json()

      toast({
        title: "Voice Cloned Successfully!",
        description: `Your voice "${cloneName}" is ready to use`,
      })

      // Reload voices
      await loadVoices()
      setCloneName("")
      setCloneFiles(null)
    } catch (error) {
      toast({
        title: "Cloning Failed",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      })
    } finally {
      setIsCloning(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-white mb-4 tracking-tight">Professional Voice Studio</h1>
        <p className="text-xl text-purple-200 max-w-2xl mx-auto">
          Create YouTube-ready voiceovers with AI • 100% Monetizable • Non-Copyright • Multi-language
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-5xl mx-auto">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="tts" className="text-lg">
            <Volume2 className="mr-2 h-5 w-5" />
            Text to Speech
          </TabsTrigger>
          <TabsTrigger value="clone" className="text-lg">
            <Mic className="mr-2 h-5 w-5" />
            Clone Your Voice
          </TabsTrigger>
        </TabsList>

        {/* Text-to-Speech Tab */}
        <TabsContent value="tts">
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Volume2 className="h-6 w-6" />
                Generate Professional Voiceover
              </CardTitle>
              <CardDescription className="text-purple-200">
                Perfect for YouTube videos, podcasts, and content creation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Voice Selection */}
              <div className="space-y-2">
                <Label htmlFor="voice" className="text-white flex items-center gap-2">
                  <Languages className="h-4 w-4" />
                  Select Voice (Multi-language Support)
                </Label>
                <div className="flex gap-2">
                  <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                    <SelectTrigger id="voice" className="bg-slate-800 text-white border-purple-500/30">
                      <SelectValue placeholder="Select a voice" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 text-white border-purple-500/30">
                      <SelectItem value="JBFqnCBsd6RMkjVDRZzb">George - Calm & Authoritative (Default)</SelectItem>
                      {voices.map((voice) => (
                        <SelectItem key={voice.voice_id} value={voice.voice_id}>
                          {voice.name}
                          {voice.labels?.accent && ` - ${voice.labels.accent}`}
                          {voice.labels?.language && ` (${voice.labels.language})`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    onClick={loadVoices}
                    disabled={isLoadingVoices}
                    variant="outline"
                    className="border-purple-500/30 bg-transparent"
                  >
                    {isLoadingVoices ? <Loader2 className="h-4 w-4 animate-spin" /> : "Load Voices"}
                  </Button>
                </div>
              </div>

              {/* Voice Style Info */}
              <div className="p-4 bg-purple-900/30 rounded-lg border border-purple-500/20">
                <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                  <Wand2 className="h-4 w-4" />
                  YouTube Optimization Settings
                </h3>
                <p className="text-purple-200 text-sm">
                  Default voice optimized for: Calm, deep, authoritative tone • Motivational content • Self-discipline
                  videos • Maximum retention • Mature audience
                </p>
              </div>

              {/* Text Input */}
              <div className="space-y-2">
                <Label htmlFor="text" className="text-white">
                  Your Script (Urdu, English, Arabic, Hindi, and 30+ languages supported)
                </Label>
                <Textarea
                  id="text"
                  placeholder="Enter your script here... مثال کے طور پر: آج میں آپ کو ایک اہم سبق بتاؤں گا..."
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="min-h-[200px] bg-slate-800 text-white border-purple-500/30 placeholder:text-slate-400"
                />
                <p className="text-sm text-purple-300">
                  Characters: {text.length} • Supports Urdu (اردو), English, Arabic (عربی), Hindi, and more
                </p>
              </div>

              {/* Voice Settings */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-white">Stability: {stability[0].toFixed(2)}</Label>
                  <Slider value={stability} onValueChange={setStability} max={1} step={0.01} className="py-4" />
                  <p className="text-xs text-purple-300">Higher = More consistent, Lower = More expressive</p>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Similarity Boost: {similarity[0].toFixed(2)}</Label>
                  <Slider value={similarity} onValueChange={setSimilarity} max={1} step={0.01} className="py-4" />
                  <p className="text-xs text-purple-300">Higher = Closer to original voice</p>
                </div>
              </div>

              {/* Generate Button */}
              <Button
                onClick={generateSpeech}
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-6 text-lg"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Generating Professional Voice...
                  </>
                ) : (
                  <>
                    <Volume2 className="mr-2 h-5 w-5" />
                    Generate YouTube-Ready Voice
                  </>
                )}
              </Button>

              {/* Audio Player & Download */}
              {audioUrl && (
                <div className="space-y-4 p-6 bg-green-900/20 rounded-lg border border-green-500/30">
                  <div className="flex items-center justify-between">
                    <h3 className="text-white font-semibold">✓ Your Voiceover is Ready!</h3>
                    <Button
                      onClick={downloadAudio}
                      variant="outline"
                      className="border-green-500/50 text-green-400 hover:bg-green-500/10 bg-transparent"
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Download MP3
                    </Button>
                  </div>
                  <audio ref={audioRef} src={audioUrl} controls className="w-full" />
                  <p className="text-sm text-green-300">
                    ✓ 100% Copyright-free • ✓ YouTube Monetizable • ✓ Commercial Use Allowed
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Voice Cloning Tab */}
        <TabsContent value="clone">
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Mic className="h-6 w-6" />
                Clone Your Voice
              </CardTitle>
              <CardDescription className="text-purple-200">
                Upload audio samples of your voice to create a personalized AI voice clone
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Instructions */}
              <div className="p-4 bg-blue-900/30 rounded-lg border border-blue-500/20">
                <h3 className="text-white font-semibold mb-2">How to Clone Your Voice:</h3>
                <ul className="text-blue-200 text-sm space-y-1 list-disc list-inside">
                  <li>Record 1-3 minutes of clear audio samples</li>
                  <li>Speak naturally in a quiet environment</li>
                  <li>Include varied sentences and emotions</li>
                  <li>Upload MP3, WAV, or M4A files</li>
                  <li>Best results with multiple short clips (1-5 mins each)</li>
                </ul>
              </div>

              {/* Voice Name */}
              <div className="space-y-2">
                <Label htmlFor="cloneName" className="text-white">
                  Voice Name
                </Label>
                <input
                  id="cloneName"
                  type="text"
                  placeholder="e.g., My Professional Voice"
                  value={cloneName}
                  onChange={(e) => setCloneName(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 text-white border border-purple-500/30 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>

              {/* File Upload */}
              <div className="space-y-2">
                <Label htmlFor="audioFiles" className="text-white">
                  Upload Audio Samples (1-5 files)
                </Label>
                <div className="border-2 border-dashed border-purple-500/30 rounded-lg p-8 text-center bg-slate-800/50">
                  <input
                    id="audioFiles"
                    type="file"
                    accept="audio/*"
                    multiple
                    onChange={(e) => setCloneFiles(e.target.files)}
                    className="hidden"
                  />
                  <label htmlFor="audioFiles" className="cursor-pointer">
                    <Mic className="h-12 w-12 mx-auto mb-4 text-purple-400" />
                    <p className="text-white mb-2">Click to upload audio files</p>
                    <p className="text-sm text-purple-300">MP3, WAV, M4A up to 10MB each</p>
                  </label>
                </div>
                {cloneFiles && cloneFiles.length > 0 && (
                  <div className="text-green-400 text-sm">✓ {cloneFiles.length} file(s) selected</div>
                )}
              </div>

              {/* Clone Button */}
              <Button
                onClick={cloneVoice}
                disabled={isCloning}
                className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white py-6 text-lg"
              >
                {isCloning ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Cloning Your Voice...
                  </>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-5 w-5" />
                    Clone My Voice
                  </>
                )}
              </Button>

              {/* Note */}
              <div className="p-4 bg-yellow-900/20 rounded-lg border border-yellow-500/20">
                <p className="text-yellow-200 text-sm">
                  <strong>Note:</strong> Voice cloning may take 2-5 minutes. Once completed, your cloned voice will
                  appear in the voice selection dropdown in the Text-to-Speech tab.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Features Footer */}
      <div className="mt-12 grid md:grid-cols-4 gap-6 max-w-5xl mx-auto">
        <div className="text-center p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
          <Volume2 className="h-8 w-8 mx-auto mb-2 text-purple-400" />
          <h3 className="text-white font-semibold mb-1">Multi-Language</h3>
          <p className="text-purple-200 text-sm">30+ languages including Urdu, English, Arabic</p>
        </div>
        <div className="text-center p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
          <Mic className="h-8 w-8 mx-auto mb-2 text-blue-400" />
          <h3 className="text-white font-semibold mb-1">Voice Cloning</h3>
          <p className="text-purple-200 text-sm">Clone your own voice for personal branding</p>
        </div>
        <div className="text-center p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
          <Download className="h-8 w-8 mx-auto mb-2 text-green-400" />
          <h3 className="text-white font-semibold mb-1">Download Ready</h3>
          <p className="text-purple-200 text-sm">High-quality MP3 files for any platform</p>
        </div>
        <div className="text-center p-4 bg-slate-800/50 rounded-lg border border-purple-500/20">
          <Wand2 className="h-8 w-8 mx-auto mb-2 text-pink-400" />
          <h3 className="text-white font-semibold mb-1">YouTube Optimized</h3>
          <p className="text-purple-200 text-sm">100% monetizable, copyright-free</p>
        </div>
      </div>
    </div>
  )
}
